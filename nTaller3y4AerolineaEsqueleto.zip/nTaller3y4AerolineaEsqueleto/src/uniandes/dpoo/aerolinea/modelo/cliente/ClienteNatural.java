package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente {
    public static final String NATURAL = "natural";
    private String nombre;
    private String identificador;

    public ClienteNatural(String nombre, String identificador) {
        this.nombre = nombre;
        this.identificador = identificador;
    }

    public String getIdentificador(){
        return identificador;
    }

    public String getTipoCliente(){
        return NATURAL;
    }

    public String getNombre(){
        return nombre;
    }
}
