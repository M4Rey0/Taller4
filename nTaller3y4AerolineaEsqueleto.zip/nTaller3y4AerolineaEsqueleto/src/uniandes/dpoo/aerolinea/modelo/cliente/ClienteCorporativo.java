package uniandes.dpoo.aerolinea.modelo.cliente;

import org.json.JSONObject;

import uniandes.dpoo.aerolinea.exceptions.ClienteRepetidoException;

/**
 * Esta clase se usa para representar a los clientes de la aerolínea que son empresas
 */
public class ClienteCorporativo extends Cliente
{
    
    public static final String CORPORATIVO = "corporativo";
    private static int GRANDE = 1;
    private static int MEDIANA = 2;
    private static int PEQUEÑA = 3;
    private String identificador;

    private String nombreEmpresa;
    private int tamanoEmpresa;


    public ClienteCorporativo(String nombreEmpresa, int tamanoEmpresa, String identificador) {
        this.nombreEmpresa = nombreEmpresa;
        this.identificador = identificador;
        switch (tamanoEmpresa) {
            case 1:
                this.tamanoEmpresa = GRANDE;
                break;
            case 2:
                this.tamanoEmpresa = MEDIANA;
                break;
            case 3:
                this.tamanoEmpresa = PEQUEÑA;
                break;
        }
    }

    /**
     * Retorna el nombre de la empresa
     * @return
     */
    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    /**
     * Retorna el tamaño de la empresa
     * @return
     */
    public int getTamanoEmpresa() {
        return tamanoEmpresa;
    }

    /**
     * Retorna el tipo de cliente
     * @return
     */
    public String getTipoCliente() {
        return CORPORATIVO;
    }


    /**
     * Crea un nuevo objeto de tipo a partir de un objeto JSON.
     * 
     * El objeto JSON debe tener dos atributos: nombreEmpresa (una cadena) y tamanoEmpresa (un número).
     * @param cliente El objeto JSON que contiene la información
     * @return El nuevo objeto inicializado con la información
     */
    public static ClienteCorporativo cargarDesdeJSON( JSONObject cliente )
    {
        String nombreEmpresa = cliente.getString( "nombreEmpresa" );
        int tam = cliente.getInt( "tamanoEmpresa" );
        String identificador = cliente.getString( "identificador" );
        return new ClienteCorporativo( nombreEmpresa, tam , identificador);
    }

    /**
     * Salva este objeto de tipo ClienteCorporativo dentro de un objeto JSONObject para que ese objeto se almacene en un archivo
     * @return El objeto JSON con toda la información del cliente corporativo
     */
    public JSONObject salvarEnJSON( )
    {
        JSONObject jobject = new JSONObject( );
        jobject.put( "nombreEmpresa", this.nombreEmpresa );
        jobject.put( "tamanoEmpresa", this.tamanoEmpresa );
        jobject.put( "tipoCliente", CORPORATIVO );
        jobject.put( "identificador", this.identificador );
        return jobject;
    }

    /**
     * Retorna el identificador del cliente
     * @return
     */
    public String getIdentificador() {
        return identificador;
    }
}
