package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente {

    public abstract String getTipoCliente();

    public abstract String getIdentificador();

    public void agregarTiquete(Tiquete tiquete){
        tiquetesSinUsar.add(tiquete);
    }

    private List<Tiquete> tiquetesSinUsar = new ArrayList<>();
    private List<Tiquete> tiquetesUsados = new ArrayList<>();

    /**
     * Calcula el valor total de los tiquetes que tiene el cliente
     * @return
     */
    public int calcularValorTotalTiquetes(){

        int tarifaTotal = 0;
        for (Tiquete tiquete : tiquetesSinUsar) {
            tiquete.getTarifa();
            tarifaTotal += tiquete.getTarifa();
        }

        for (Tiquete tiquete : tiquetesUsados) {
            tiquete.getTarifa();
            tarifaTotal += tiquete.getTarifa();
        }

        return tarifaTotal;
    }

    /**
     * Agrega un tiquete a la lista de tiquetes usados
     * @param vuelo
     */
    public void usarTiquetes(Vuelo vuelo){

        for (Tiquete tiquete : tiquetesSinUsar) {
            if (tiquete.getVuelo().equals(vuelo)){
                tiquetesUsados.add(tiquete);
                tiquete.marcarComoUsado();
                tiquetesSinUsar.remove(tiquete);
            }
        }
    }
}
