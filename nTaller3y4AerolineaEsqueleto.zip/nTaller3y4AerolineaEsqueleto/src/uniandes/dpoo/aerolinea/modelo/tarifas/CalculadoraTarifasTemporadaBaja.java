package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas{

    private static int COSTO_POR_KM_NATURAL = 600;
    private static int COSTO_POR_KM_CORPORATIVO = 900;
    private static double DESCUENTO_PEQ = 0.02;
    private static double DESCUENTO_MEDIANAS = 0.1;
    private static double DESCUENTO_GRANDES = 0.2;

    /**
     * Calcula el costo base de un vuelo para un cliente
     * @param vuelo
     * @param cliente
     * @return costo base
     */
    @Override
    protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
        int distancia = calcularDistanciaVuelo(vuelo.getRuta());
        int costoBase = 0;
        if(cliente.getTipoCliente().equals("natural")){
            costoBase = distancia * COSTO_POR_KM_NATURAL;
        }else if(cliente.getTipoCliente().equals("corporativo")){
            costoBase = distancia * COSTO_POR_KM_CORPORATIVO;
        }
        return costoBase;
    }

    /**
     * Calcula el porcentaje de descuento para un cliente
     * @param cliente
     * @return porcentaje de descuento
     */
    @Override
    protected double calcularPorcentajeDescuento(Cliente cliente) {
        if (cliente.getTipoCliente().equals("corporativo")) {
            switch (((ClienteCorporativo) cliente).getTamanoEmpresa()) {
                case 3:
                    return DESCUENTO_PEQ;
                case 2:
                    return DESCUENTO_MEDIANAS;
                case 1:
                    return DESCUENTO_GRANDES;
            }
        }

        return 0;
    }
    
}
