package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas {
    
    private static double IMPUESTO = 0.28;

    /**
     * Calcula la tarifa de un vuelo para un cliente
     * @param vuelo
     * @param cliente
     * @return tarifa
     */
    public double calcularTarifa(Vuelo vuelo, Cliente cliente){
        int costoBase = calcularCostoBase(vuelo, cliente);
        double tarifa = costoBase - (costoBase * calcularPorcentajeDescuento(cliente));
        double impuestos = calcularValorImpuestos((int) tarifa);
        tarifa += impuestos;
        return tarifa;
    }

    protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);

    protected abstract double calcularPorcentajeDescuento(Cliente cliente);

    /**
     * Calcula la distancia de un vuelo
     * @param ruta
     * @return distancia en KM
     */
    protected int calcularDistanciaVuelo(Ruta ruta){
        return Aeropuerto.calcularDistancia(ruta.getOrigen(), ruta.getDestino());
    }
    /**
     * Calcula el valor de los impuestos
     * @param costoBase
     * @return valor de los impuestos
     */
    protected int calcularValorImpuestos(int costoBase){
        return (int) (costoBase * IMPUESTO);
    }

}
