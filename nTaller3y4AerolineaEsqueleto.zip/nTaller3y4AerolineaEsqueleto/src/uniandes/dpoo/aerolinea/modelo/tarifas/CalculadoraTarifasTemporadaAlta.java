package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas{

    private static int COSTO_POR_KM = 1000;

    /**
     * Calcula el costo base de un vuelo para un cliente
     * @param vuelo
     * @param cliente
     * @return costo base
     */
    @Override
    protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) {
        return calcularDistanciaVuelo(vuelo.getRuta()) * COSTO_POR_KM;
    }

    /**
     * Calcula el porcentaje de descuento para un cliente
     * @param cliente
     * @return porcentaje de descuento
     */
    @Override
    protected double calcularPorcentajeDescuento(Cliente cliente) {
        return 0;
    }
    
}
