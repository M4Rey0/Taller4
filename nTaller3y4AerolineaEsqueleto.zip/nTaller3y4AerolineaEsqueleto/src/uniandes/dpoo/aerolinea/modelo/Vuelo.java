package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {

    private String fecha;
    private Ruta ruta;
    private Avion avion;
    private Map<String, Tiquete> tiquetes = new HashMap<>();

    public Vuelo(String fecha, Ruta ruta, Avion avion) {
        this.fecha = fecha;
        this.ruta = ruta;
        this.avion = avion;
    }

    public String getFecha() {
        return fecha;
    }

    public Ruta getRuta() {
        return ruta;
    }

    public Avion getAvion() {
        return avion;
    }

    public Collection<Tiquete> getTiquetes() {
        return tiquetes.values();
    }  

    /**
     * 
     * @param cliente
     * @param calculadora
     * @param cantidad
     * @return
     */
    public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad){
        
        int tarifa = 0;

        for (int i = 0; i < cantidad; i++) {

            if (avion.getCapacidad() == tiquetes.size()) {
                return -1;
            }

            tarifa += (int) calculadora.calcularTarifa(this, cliente);
            Tiquete tiquete = GeneradorTiquetes.generarTiquete(this, cliente, tarifa);
            boolean verificar = GeneradorTiquetes.validarTiquete(tiquete.getCodigo());
            if (!verificar){
                GeneradorTiquetes.registrarTiquete(tiquete);
                tiquetes.put(tiquete.getCodigo(), tiquete);
                cliente.agregarTiquete(tiquete);
            }   
        }
        
        return tarifa;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Vuelo vuelo = (Vuelo) obj;
        return fecha.equals(vuelo.getFecha()) && ruta.equals(vuelo.getRuta()) && avion.equals(vuelo.getAvion());
    }

    public void setTiquetes(Map<String, Tiquete> tiquetes) {
        this.tiquetes = tiquetes;
    }

}
