package uniandes.dpoo.aerolinea.modelo;

public class TestA {

    public static void main(String[] args) {
        Ruta ruta = new Ruta(null, null, "1530", "1600", "123123");
        System.out.println(ruta.getDuracionVuelo());
    }
}
