package uniandes.dpoo.aerolinea.consola;

import java.io.IOException;

import uniandes.dpoo.aerolinea.exceptions.AeropuertoDuplicadoException;
import uniandes.dpoo.aerolinea.exceptions.InformacionInconsistenteException;
import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteNatural;
import uniandes.dpoo.aerolinea.persistencia.CentralPersistencia;
import uniandes.dpoo.aerolinea.persistencia.TipoInvalidoException;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class ConsolaArerolinea extends ConsolaBasica
{
    private Aerolinea unaAerolinea;

    /**
     * Es un método que corre la aplicación y realmente no hace nada interesante: sólo muestra cómo se podría utilizar la clase Aerolínea para hacer pruebas.
     * @throws Exception 
     * @throws VueloSobrevendidoException 
     */
    public void correrAplicacion( ) throws VueloSobrevendidoException, Exception
    {
        try
        {
            unaAerolinea = new Aerolinea( );
            // String archivo = this.pedirCadenaAlUsuario( "Digite el nombre del archivo json con la información de una aerolinea" );
            String archivo = "tiquetes.json"; 

            // ahora estas pruebas no funcionan porque ya se ejecutaron y se guardaron
            /** 
            Avion avion = new Avion ( "Boeing 747", 500);
            unaAerolinea.agregarAvion( avion );

            Aeropuerto aeropuerto = new Aeropuerto( "El Dorado", "BOG", "Bogotá", 4.7016, -74.1469 );
            unaAerolinea.agregarAeropuerto( aeropuerto );

            Aeropuerto aeropuerto2 = new Aeropuerto( "Jose Maria Cordova", "MDE", "Medellin", 6.1645, -75.4231 );
            unaAerolinea.agregarAeropuerto( aeropuerto2 );

            Ruta ruta = new Ruta( aeropuerto, aeropuerto2, "1200", "1400", "BOG-MDE");
            unaAerolinea.agregarRuta(ruta);

            Vuelo vuelo = new Vuelo( "2021-10-10", ruta, avion);
            unaAerolinea.agregarVuelo( vuelo );

            unaAerolinea.cargarTiquetes( "./datos/" + archivo, CentralPersistencia.JSON );

            Cliente cliente = unaAerolinea.getCliente( "312312312" );

            try{
                unaAerolinea.venderTiquetes( cliente.getIdentificador(), vuelo.getFecha(), ruta.getCodigoRuta(), 500000 );
            } catch (VueloSobrevendidoException e){
                System.out.println("Vuelo sobrevendido");
            }   

            
            unaAerolinea.salvarTiquetes("./datos/tiquetes.json", "JSON");
            */

            unaAerolinea.cargarAerolinea("./datos/aerolinea.json", CentralPersistencia.JSON);
            unaAerolinea.cargarTiquetes("./datos/tiquetes.json", CentralPersistencia.JSON);

            //unaAerolinea.programarVuelo("2021-10-10", "BOG-MDE", "Boeing 747");

            //unaAerolinea.venderTiquetes("7489126498126498", "2021-10-10", "BOG-MDE", 5);

            unaAerolinea.registrarVueloRealizado("2021-10-10", "BOG-MDE");

            unaAerolinea.salvarAerolinea( "./datos/aerolinea.json", CentralPersistencia.JSON );
            unaAerolinea.salvarTiquetes( "./datos/tiquetes.json", CentralPersistencia.JSON );

        }


        catch( TipoInvalidoException e )
        {
            e.printStackTrace( );
        }
        catch( IOException e )
        {
            e.printStackTrace();
        }
        catch( InformacionInconsistenteException e )
        {
            e.printStackTrace();
        }
    }

    public static void main( String[] args )
    {
        ConsolaArerolinea ca = new ConsolaArerolinea( );
        try {
            ca.correrAplicacion( );
        } catch (AeropuertoDuplicadoException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (VueloSobrevendidoException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
