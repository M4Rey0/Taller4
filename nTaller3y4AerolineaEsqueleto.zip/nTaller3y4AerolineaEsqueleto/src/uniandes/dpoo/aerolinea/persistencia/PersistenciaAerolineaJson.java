package uniandes.dpoo.aerolinea.persistencia;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;

import org.json.JSONArray;
import org.json.JSONObject;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea{

    private static final String VUELOS = "vuelos";
    private static final String AVIONES = "aviones";
    private static final String RUTAS = "rutas";
    private static final String AEROPUERTOS= "aeropuertos";

    //constantes para vuelos

    private static final String AVION = "avion";
    private static final String FECHA = "fecha";
    private static final String RUTA = "ruta";

    //constantes para aviones
    private static final String NOMBRE_AVION = "nombre";
    private static final String CAPACIDAD = "capacidad";

    //constantes para rutas
    private static final String CODIGO_RUTA = "codigo";
    private static final String ORIGEN = "origen"; // codigo del aeropuerto
    private static final String DESTINO = "destino"; //codigo del aeropuerto
    private static final String HORA_SALIDA = "hora_salida";
    private static final String HORA_LLEGADA = "hora_llegada";
    
    //constantes para aeropuertos 
    private static final String NOMBRE_AEROPUERTO = "nombre";
    private static final String CIUDAD = "ciudad";
    private static final String CODIGO = "codigo";
    private static final String LATITUD = "latitud";
    private static final String LONGITUD = "longitud";

    
    

    


    @Override
    public void cargarAerolinea(String archivo, Aerolinea aerolinea) {
        String jsonCompleto;
        try {
            jsonCompleto = new String( Files.readAllBytes( new File( archivo ).toPath( ) ) );
            JSONObject raiz = new JSONObject( jsonCompleto );
            cargarAviones(aerolinea, raiz.getJSONArray(AVIONES));
            cargarAeropuertos(aerolinea, raiz.getJSONArray(AEROPUERTOS));
            cargarRutas(aerolinea, raiz.getJSONArray(RUTAS));
            cargarVuelos(aerolinea, raiz.getJSONArray(VUELOS));

        } catch (IOException e) {
            
            e.printStackTrace();
        }
        

    }

    @Override
    public void salvarAerolinea(String archivo, Aerolinea aerolinea) {
        JSONArray aviones = new JSONArray();
        JSONArray vuelos = new JSONArray();
        JSONArray rutas = new JSONArray();
        JSONArray aeropuertos = new JSONArray();

        for (Avion avion : aerolinea.getAviones()) {
            JSONObject avionJson = new JSONObject();
            avionJson.put(NOMBRE_AVION, avion.getNombre());
            avionJson.put(CAPACIDAD, avion.getCapacidad());
            aviones.put(avionJson);
        }

        for (Vuelo vuelo: aerolinea.getVuelos()) {
            JSONObject vueloJson = new JSONObject();
            vueloJson.put(AVION, vuelo.getAvion().getNombre());
            vueloJson.put(FECHA, vuelo.getFecha());
            vueloJson.put(RUTA, vuelo.getRuta().getCodigoRuta());
            vuelos.put(vueloJson);
        }

        for (Aeropuerto aeropuerto: aerolinea.getAeropuertos()) {
            JSONObject aeropuertoJson = new JSONObject();
            aeropuertoJson.put(NOMBRE_AEROPUERTO, aeropuerto.getNombre());
            aeropuertoJson.put(CIUDAD, aeropuerto.getNombreCiudad());
            aeropuertoJson.put(CODIGO, aeropuerto.getCodigo());
            aeropuertoJson.put(LATITUD, aeropuerto.getLatitud());
            aeropuertoJson.put(LONGITUD, aeropuerto.getLongitud());
            aeropuertos.put(aeropuertoJson);
        }

        for (Ruta ruta: aerolinea.getRutas()) {
            JSONObject rutaJson = new JSONObject();
            rutaJson.put(CODIGO_RUTA, ruta.getCodigoRuta());
            rutaJson.put(ORIGEN, ruta.getOrigen().getCodigo());
            rutaJson.put(DESTINO, ruta.getDestino().getCodigo());
            rutaJson.put(HORA_SALIDA, ruta.getHoraSalida());
            rutaJson.put(HORA_LLEGADA, ruta.getHoraLlegada());
            rutas.put(rutaJson);
        }

        try (FileWriter file = new FileWriter(archivo)) {
            JSONObject aerolineaJson = new JSONObject();
            aerolineaJson.put(AVIONES, aviones);
            aerolineaJson.put(VUELOS, vuelos);
            aerolineaJson.put(RUTAS, rutas);
            aerolineaJson.put(AEROPUERTOS, aeropuertos);
            PrintWriter pw = new PrintWriter( archivo );
            aerolineaJson.write( pw, 2, 0 );
            pw.close( );
        } catch (IOException e) {
            e.printStackTrace();
        }
        
    }

    private void cargarAviones(Aerolinea aerolinea, JSONArray jAviones) {
        
        int numAviones = jAviones.length();
        for (int i = 0; i < numAviones; i++) {
            JSONObject jAvion = jAviones.getJSONObject(i);
            String nombre = jAvion.getString(NOMBRE_AVION);
            int capacidad = jAvion.getInt(CAPACIDAD);
            aerolinea.agregarAvion(new Avion(nombre, capacidad));
        }
    }
    
    private void cargarAeropuertos(Aerolinea aerolinea, JSONArray jAeropuertos) {
        int numAeropuertos = jAeropuertos.length();
        for (int i = 0; i < numAeropuertos; i++) {
            JSONObject jAeropuerto = jAeropuertos.getJSONObject(i);
            String nombre = jAeropuerto.getString(NOMBRE_AEROPUERTO);
            String ciudad = jAeropuerto.getString(CIUDAD);
            String codigo = jAeropuerto.getString(CODIGO);
            double latitud = jAeropuerto.getDouble(LATITUD);
            double longitud = jAeropuerto.getDouble(LONGITUD);
            try {
                aerolinea.agregarAeropuerto(new Aeropuerto(nombre, codigo, ciudad, latitud, longitud));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void cargarRutas(Aerolinea aerolinea, JSONArray jRutas) {
        int numRutas = jRutas.length();
        for (int i = 0; i < numRutas; i++) {
            JSONObject jRuta = jRutas.getJSONObject(i);
            String codigo = jRuta.getString(CODIGO_RUTA);
            String origen = jRuta.getString(ORIGEN);
            String destino = jRuta.getString(DESTINO);
            String horaSalida = jRuta.getString(HORA_SALIDA);
            String horaLlegada = jRuta.getString(HORA_LLEGADA);
            try {
                aerolinea.agregarRuta(new Ruta(aerolinea.getAeropuerto(destino), aerolinea.getAeropuerto(origen), horaSalida, horaLlegada, codigo));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void cargarVuelos(Aerolinea aerolinea, JSONArray jVuelos) {
        int numVuelos = jVuelos.length();
        for (int i = 0; i < numVuelos; i++) {
            JSONObject jVuelo = jVuelos.getJSONObject(i);
            String fecha = jVuelo.getString(FECHA);
            String avion = jVuelo.getString(AVION);
            String ruta = jVuelo.getString(RUTA);
            try {
                aerolinea.agregarVuelo(new Vuelo(fecha, aerolinea.getRuta(ruta), aerolinea.getAvion(avion)));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
